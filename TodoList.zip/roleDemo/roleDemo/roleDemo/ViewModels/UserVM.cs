﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace roleDemo.ViewModels {
    public class UserVM {
        public string Email { get; set; }
    }
}
